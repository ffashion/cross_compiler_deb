#ifndef _ASM_MIPS_UNISTD_NR_N64_H
#define _ASM_MIPS_UNISTD_NR_N64_H

#define __NR_64_Linux	5000
#define __NR_64_Linux_syscalls	329

#endif /* _ASM_MIPS_UNISTD_NR_N64_H */
