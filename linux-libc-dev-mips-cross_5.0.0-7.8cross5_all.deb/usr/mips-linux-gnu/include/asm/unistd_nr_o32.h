#ifndef _ASM_MIPS_UNISTD_NR_O32_H
#define _ASM_MIPS_UNISTD_NR_O32_H

#define __NR_O32_Linux	4000
#define __NR_O32_Linux_syscalls	369

#endif /* _ASM_MIPS_UNISTD_NR_O32_H */
