#ifndef _ASM_MIPS_UNISTD_NR_N32_H
#define _ASM_MIPS_UNISTD_NR_N32_H

#define __NR_N32_Linux	6000
#define __NR_N32_Linux_syscalls	333

#endif /* _ASM_MIPS_UNISTD_NR_N32_H */
